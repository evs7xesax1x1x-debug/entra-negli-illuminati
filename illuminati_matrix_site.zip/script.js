const canvas = document.getElementById("matrix");
const ctx = canvas.getContext("2d");

let width;
let height;
let columns;
let drops;
const fontSize = 18;
const chars = "01アイウエオカキクケコサシスセソABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";

function resize() {
  width = canvas.width = window.innerWidth * devicePixelRatio;
  height = canvas.height = window.innerHeight * devicePixelRatio;
  canvas.style.width = window.innerWidth + "px";
  canvas.style.height = window.innerHeight + "px";

  ctx.setTransform(devicePixelRatio, 0, 0, devicePixelRatio, 0, 0);

  columns = Math.floor(window.innerWidth / fontSize);
  drops = Array(columns).fill(0).map(() => Math.random() * -40);
}

function drawMatrix() {
  ctx.fillStyle = "rgba(0, 0, 0, 0.08)";
  ctx.fillRect(0, 0, window.innerWidth, window.innerHeight);

  ctx.font = fontSize + "px monospace";

  for (let i = 0; i < drops.length; i++) {
    const char = chars[Math.floor(Math.random() * chars.length)];
    const x = i * fontSize;
    const y = drops[i] * fontSize;

    ctx.fillStyle = Math.random() > 0.97 ? "#d6ffe0" : "#27e85b";
    ctx.fillText(char, x, y);

    if (y > window.innerHeight && Math.random() > 0.975) {
      drops[i] = Math.random() * -20;
    }

    drops[i] += 0.75 + Math.random() * 0.35;
  }

  requestAnimationFrame(drawMatrix);
}

document.getElementById("enterBtn").addEventListener("click", () => {
  const terminal = document.getElementById("terminal");
  terminal.classList.remove("hidden");
  document.body.animate(
    [
      { filter: "brightness(1)" },
      { filter: "brightness(2.2)" },
      { filter: "brightness(.8)" },
      { filter: "brightness(1)" }
    ],
    { duration: 480, iterations: 1 }
  );
});

window.addEventListener("resize", resize);

resize();
drawMatrix();
