SITO MATRIX — ENTRA NEGLI ILLUMINATI

1. Apri index.html con un browser per vedere il sito.
2. I file necessari sono:
   - index.html
   - style.css
   - script.js
3. Per pubblicarlo gratis puoi caricare questi file su GitHub Pages o Netlify.
